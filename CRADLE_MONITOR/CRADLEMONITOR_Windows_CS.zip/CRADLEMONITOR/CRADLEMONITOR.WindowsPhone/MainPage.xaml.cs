﻿using Windows.UI.Xaml.Controls;

namespace CRADLEMONITOR
{
    public sealed partial class MainPage : Page
    {
    }
}
